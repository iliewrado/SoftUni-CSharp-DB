﻿namespace SoftJail.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=SoftJail;User Id=sa;Password=Radoslav!;encrypt=false;";
    }
}
